export const data = {
    title:"About",
    description:"Driven by a deep passion for technology and equipped with extensive knowledge in software development, I am actively seeking opportunities to make an impact in the evolving world of technology.",

}